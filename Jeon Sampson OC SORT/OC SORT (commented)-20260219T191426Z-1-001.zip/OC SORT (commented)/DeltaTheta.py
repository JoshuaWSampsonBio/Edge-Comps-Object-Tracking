# deltatheta --> checks if the object is moving in a consistent direction with its past movement.

# This function computes the angle difference between the motion from the predicted position 
# to the observed detection, and the "intention" direction from the predicted position to where the track was previously.

# When tracking, OCSORT wants to answer: “Is this detection the same fly as this track?”

import numpy as np

# helper: convert bbox -> center point
def _center(box):
    # box = [x1, y1, x2, y2]
    cx = (box[0] + box[2]) / 2.0
    cy = (box[1] + box[3]) / 2.0

    return cx, cy
    # returns (center_x, center_y)

def DeltaTheta(pastobservation, observation, prediction):
    px, py = _center(prediction)
    # center of predicted box (KF prediction)
    ox, oy = _center(observation)
    # center of the detection we’re trying to match
    pastx, pasty = _center(pastobservation)
    # center of the last detection that was matched to this track

    # calcuating how far and in what direction the track moved from its predicted position to the new observed position
    dx1 = ox - px # change in x from predicted to observed
    dy1 = oy - py # change in y from predicted to observed

    # using the past motion direction to predict which detection is plausible.
    # checks for intention consistency: is the track moving in a consistent direction with its past movement?
    dx2 = pastx - px
    dy2 = pasty - py


    theta_track = np.arctan2(dy1, dx1)    # angle of "predicted->observed" motion
    theta_intention = np.arctan2(dy2, dx2)    # angle of "predicted->past" direction reference


    return abs(theta_track - theta_intention)
    # return absolute difference in angles, how much the object would need to turn for this detection to be consistent with its past movement direction.
    # - small => consistent direction
    # - large => inconsistent (maybe wrong match)
